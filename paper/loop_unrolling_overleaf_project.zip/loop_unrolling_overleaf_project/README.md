# Overleaf project: Loop Unrolling in HLS

## How to use
1. In Overleaf, choose **New Project -> Upload Project**.
2. Upload the ZIP file containing this folder.
3. Set `main.tex` as the main document if Overleaf does not select it automatically.
4. Compile with pdfLaTeX and BibTeX (Overleaf handles this automatically after a second compile).

## Folder structure
- `main.tex` - second IEEE-style draft.
- `references.bib` - BibTeX database. Each entry contains a `note` explaining its relationship to the seminar topic, as requested in the HW/SW Co-design instructions.
- `figures/` - charts, RTL schematics, source-code screenshot, and representative Vitis reports.
- `data/results.csv` - the numerical data used for the tables and charts.
- `sources/` - the provided main paper, course instructions, tool documentation, background sources, and previous draft.

## Important academic note
The course instructions state that every sentence must be of the author's intellectual origin. Treat `main.tex` as a structured technical scaffold. Verify every number against the supplied reports and rewrite the argument in your own words before submission. Keep citations attached to ideas derived from external sources.

## Target length
The project is formatted with the IEEE conference template and is designed to be close to the requested five-page paper. Page count can shift slightly after edits, bibliography changes, or different TeX installations.
